
from django.contrib import admin
from django.urls import path,include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',include('base.urls',namespace="base")),
    path('org/',include('organization.urls',namespace="org")),
    path('users/',include('users.urls',namespace="users")),
    path('chapa_webhook', include('django_chapa.urls'))
]
