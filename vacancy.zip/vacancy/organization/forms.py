from django import forms
from .models import *
class Chereta_form(forms.ModelForm):
    class Meta:
        model=Chereta
        fields=['title',"open_at","close_at","opened_by","description","location"]
class Advert_form(forms.ModelForm):
    class Meta:
        model=Post_advert
        fields=['title','descr']
        
