from django.db import models
from django.contrib.auth.models import User
from ckeditor.fields import RichTextField
class Organ(models.Model):
    name_of_org=models.CharField(max_length=255,null=True)
    size_org=models.CharField(max_length=255,null=True)
    need_us_form=models.BooleanField(default=False,null=True)
    activ=models.BooleanField(default=False,null=True)
    def __str__(self):
        return self.name_of_org
class Chereta(models.Model):
    title=models.CharField(max_length=255,null=True)
    open_at=models.DateTimeField(null=True)
    open_time=models.DateTimeField(null=True)
    close_time=models.DateTimeField(null=True)
    close_at=models.DateTimeField(null=True)
    opened_by=models.CharField(max_length=255,null=True)
    posted_at=models.DateTimeField(null=True,auto_now=True)
    posted_by=models.ForeignKey(User,on_delete=models.CASCADE,null=True)
    description=RichTextField( blank=True,null=True)
    location=models.CharField(max_length=255,null=True)
    
    def __str__(self):
        return self.title
    
class Register_bid(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE,null=True)
    chereta=models.ForeignKey(Chereta,on_delete=models.CASCADE,null=True)
    at=models.DateTimeField(auto_now=True)
class Post_advert(models.Model):
    title=models.CharField(max_length=255,null=True)
    descr=RichTextField(null=True)
    dat=models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.title
