from django.contrib import admin
from .models import *
from users.models import *
# Register your models here.
admin.site.register(Organ)
admin.site.register(Chereta)
class ChapaTransactionAdmin(admin.ModelAdmin):
    
    list_display = 'first_name', 'last_name', 'email', 'amount', 'currency', 'state'

admin.site.register(Chapa_Data, ChapaTransactionAdmin)
admin.site.register(Post_advert)