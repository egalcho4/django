from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from .models import *
from django.contrib.auth import authenticate,login
import uuid
from users.models import *
from django.contrib import messages
from django.core.paginator import Paginator
from django.http import JsonResponse

from datetime import datetime

from users.models import *
import json
from django.core.serializers import serialize
from django.contrib.auth.decorators import login_required
def signup(request):
    if request.method=="POST":
        phone=request.POST.get('tel',False)
        fname=request.POST.get('fname',False)
        lname=request.POST.get('lname',False)
        job=request.POST.get('job',False)
        pn=phone.replace(" ", "")
        user=User.objects.create_user(pn)
        user.first_name=fname
        user.last_name=lname
        user.typ=1
        user.cv=job
        user.save()
        request.session['suser']=pn
        return redirect('org:after_signup')
    return render(request,"org/signup.html")
def after_signup(request):
    phone=request.session['suser']
    user=User.objects.get(username=phone)
    otp1=uuid.uuid4().hex[0:6]
    print(otp1)
    if request.method=="POST":
        pasword=request.POST.get('pas',False)
        email=request.POST.get('email',False)
        user.set_password(pasword)
        user.email=email
        user.save()
        auser=authenticate(username=phone,password=pasword)
        if auser is not None:
            login(request,auser)
            if user.typ==1 and user.cv==2:
                return redirect('org:tender_home')
            elif user.typ==1 and user.cv==1:
                 return redirect('base:home_page')
            else:
                return redirect('base:home')
        
    return render(request,"org/aftr_signup.html",{'phone':user,"otp1":otp1})
def after_verfied(request):
    return render(request,"org/after_verfied.html")
def applications(request,id):
    blog=Blog.objects.get(id=id)
    aplied=Applid.objects.filter(job_applied=blog).order_by('-id')[:5]
    apl=Applid.objects.filter(job_applied=blog).count()
    paginator = Paginator(aplied, 5)  # Show 25 contacts per page.

    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)
    return render(request,"base/applications.html",{"page_obj":page_obj,"apl":apl})
def tender_home(request):
    if request.method=="POST":
        search_title=request.POST.get('job_search',False)
        ch=Chereta.objects.filter(title__icontains=search_title)
        user=User.objects.get(username=request.user)
        return render(request,"org/tender_home.html",{'ch':ch,'user':user})
    ch=Chereta.objects.all()
    user=User.objects.get(username=request.user)
    return render(request,"org/tender_home.html",{'ch':ch,'user':user})
def register_to_tender(request,id):
    ch=Chereta.objects.get(id=id)
    user=User.objects.get(username=request.user)
    if request.method=="POST":
        ch_reg=Register_bid.objects.get_or_create(user=user,chereta=ch)
        
        messages.success(request,"YOU ARE SUCCESSFULLY REGISTERED")
    
    return render(request,"org/tender_register.html",{'ch':ch,'user':user})
def my_registration(request):
    try:
        user=User.objects.get(username=request.user)
        my_reg=Register_bid.objects.filter(user=user)
        return render(request,"org/my_registration.html",{"applied":my_reg})
    except:
        return render(request,"org/my_registration.html")
def remove_rg(request,id):
    my_reg=Register_bid.objects.get(id=id)
    my_reg.delete()
    return redirect("org:my_registration")
    
