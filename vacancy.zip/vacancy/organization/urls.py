from django.urls import path
from .import views
app_name="org"
urlpatterns = [
    path('signup/',views.signup,name="signup"),
    path('after_signup/',views.after_signup,name="after_signup"),
     path('after_verfied/',views.after_verfied,name="after_verfied"),
     path('applications/<int:id>',views.applications,name="applications"),
     path('tender_home/',views.tender_home,name="tender_home"),
     path('register_tender/<int:id>',views.register_to_tender,name="register_tender"),
     path('my_registration/',views.my_registration,name="my_registration"),
     path('remove_rg/<int:id>',views.remove_rg,name="remove_rg"),
   
   
]
