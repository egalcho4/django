from django import forms
from .models import *
class Education_form(forms.ModelForm):
    class Meta:
        model=Education
        fields=['level','school','cgpa','year_graduate']
class Expriance_form(forms.ModelForm):
    class Meta:
        model=Expriance
        fields=['comp_name','job_title','start_date','end_date','detail']
class Skill_form(forms.ModelForm):
    class Meta:
        model=Skill
        fields=['name','level']
class Project_form(forms.ModelForm):
    class Meta:
        model=Project
        fields=['title','description']
class Chapa_form(forms.ModelForm):
    class Meta:
        model=Chapa_Data
        fields="__all__"
