from django.db import models
from django.contrib.auth.models import User
from base.models import Blog
from base.models import *
from django_chapa.models import ChapaTransactionMixin
class Chapa_Data(ChapaTransactionMixin):
    user=models.ForeignKey(User,on_delete=models.CASCADE,null=True)
    state=models.CharField(max_length=255,null=True,default="CREATED")
    dat=models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.first_name+" "+self.last_name
class Education(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE,null=True)
    level=models.CharField(max_length=255,null=True)
    school=models.CharField(max_length=255,null=True)
    cgpa=models.FloatField(null=True)
    year_graduate=models.DateField(null=True)
    
    
    def __str__(self):
         return self.level
    
class Expriance(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE,null=True)
    comp_name=models.CharField(max_length=255,null=True)
    job_title=models.CharField(max_length=255,null=True)
    start_date=models.DateField(null=True)
    end_date=models.DateField(null=True)
    detail=models.TextField(null=True)
    def __str__(self):
         return self.comp_name
class Skill(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE,null=True)
    name=models.CharField(max_length=255,null=True)
    level=models.CharField(max_length=255,null=True)
class Project(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE,null=True)
    title=models.CharField(max_length=255,null=True)
    description=models.TextField(null=True)
    
        
class User_cv(models.Model):
     cv_name=models.CharField(max_length=255,null=True)
     user=models.ForeignKey(User,on_delete=models.CASCADE,null=True)
     education=models.ManyToManyField(Education)
     expriance=models.ManyToManyField(Expriance)
     skill=models.ManyToManyField(Skill)
     project=models.ManyToManyField(Project)
class Applid(models.Model):
    applide_by=models.ForeignKey(User,on_delete=models.CASCADE,null=True)
    job_applied=models.ForeignKey(Blog,on_delete=models.CASCADE,null=True)
    cv=models.ForeignKey(User_cv,on_delete=models.CASCADE,null=True)
    
class Contact(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE,null=True)
    username=models.CharField(max_length=255,null=True)
    message=models.TextField(null=True)
    email=models.EmailField(null=True)
    replay=models.TextField(null=True)
    def __str__(self):
        return self.username
class Subscribe(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE,null=True)
    min_exp=models.IntegerField(null=True)
    max_exp=models.IntegerField(null=True)
    catagories=models.ForeignKey(Catagories,on_delete=models.CASCADE,null=True)
    salary=models.IntegerField(null=True)
    def __str__(self):
        return self.min_exp+"-"+self.max_exp
class Subscriber(models.Model):
    chat_id = models.CharField(max_length=255, unique=True)
    user=models.ForeignKey(User,on_delete=models.CASCADE,null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.chat_id