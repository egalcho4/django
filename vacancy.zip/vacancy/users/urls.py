from django.urls import path,include
from . import views
from base import views as bas_view
app_name="users"
urlpatterns = [
    path('create_cv/',views.create_cv,name="create_cv"),
    path('verfie_account/',bas_view.verfie_account,name="verfie_account"),
      path('applied/<int:id>',views.applied_job,name="applied"),
      path('my_application/',views.my_application,name="my_application"),
      path('about_us/',views.about_us,name="about_us"),
      path('contact_us/',views.contact_us,name="contact_us"),
      path('subscribe/',views.subscribe,name="subscribe"),
      path('withdraw/<int:id>',views.withdraw,name="withdraw"),
      path('unsubscribe/<int:id>',views.unsubscribe,name="unsubscribe"),
      path('webhook/', views.webhook, name='webhook'),
      path('payment/',views.payment,name="payment"),
      path('initiates_payment/',views.pay_for_marchant,name="initiates_payment"),
      path('initiate_payment',views.initiate_payment,name="initiate_payment"),
        path('job_by_catagory/<int:id>',views.list_job_by_catagory,name="job_by_catagory"),
        path('advert_detail/<int:id>',views.advert_detail,name="advert_detail"),
     
]
