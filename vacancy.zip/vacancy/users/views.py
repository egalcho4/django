from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from .forms import *
from base.models import *
from .models import User_cv
from django.contrib import messages
import requests
from django.core.serializers.json import DjangoJSONEncoder
from django.core.serializers import serialize
import socket
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Subscriber
import json
import requests
from pprint import pprint
from vacancy import settings 
import uuid
from organization.models import *
from django_chapa.views import chapa_webhook
bot_token=settings.BOT_TOKEN
bot_url=settings.BOT_URL_UP
chat_id="5792653413"
BOT_TOKEN = '7681646908:AAHcLx2etIpjpRM1hIJG3y7SHaNd-XpQh6k'  # Replace with your Telegram Bot token
# payments/views.py
import requests
from django.conf import settings
from django.http import JsonResponse
from django.conf import settings
def initiate_payment(request):
    user=User.objects.get(username=request.user)
    reference=uuid.uuid4()
    username=user.username
    first_name=user.first_name
    last_name=user.last_name
    email=user.email
    ref_id=reference
    phone="+251"+username
    if request.method == "POST":
        amount = request.POST.get('amount')
      
  
        url = "https://api.chapa.co/v1/transaction/initialize"
        headers = {
            "Authorization": f"Bearer {settings.CHAPA_SECRET_KEY}",
            "Content-Type": "application/json",
        }
        payload = {
            "amount":amount,
            "currency": "ETB",
            "email": email,
            "callback_url": "http://127.0.0.1:8000/users/payment",
            "return_url": "http://127.0.0.1:8000/users/payment",
            "first_name": first_name,
            "last_name": last_name,
           
            
        }

        # Make the request
        response = requests.post(url, json=payload, headers=headers)
        data = response.json()

        # Redirect user to Chapa payment page
        if response.status_code == 200:
            urls=data['data']['checkout_url']
            state="CREATED"
            chapa=Chapa_Data(first_name=first_name,last_name=last_name,user=user,id=ref_id,amount=amount,email=email,phone_number=phone,currency="ETB",status=state)
            chapa.save()
            messages.success(request,f"You are successfull payed {amount} ETB to mastawokia.net subscribtion")
            return redirect(urls)
            
            #return JsonResponse({"url": data['data']['checkout_url']})
        else:
            return JsonResponse({"error": "Failed to initiate payment"})

    return JsonResponse({"error": "Invalid request"}, status=400)

def pay_for_marchant(request):
    pay(request)
    user=User.objects.get(username=request.user)
    reference=uuid.uuid4().hex[:30]
    username=user.username
    first_name=user.first_name
    last_name=user.last_name
    email=user.email
    ref_id=reference
    if request.method=="POST":
       pass
    
   
    
    return render(request,"users/in_payment.html",{'username':username,"fname":first_name,"lname":last_name,"email":email,"ref":ref_id})

def pay(request):
    user=User.objects.get(username=request.user)
    reference=uuid.uuid4().hex[:30]
    username=user.username
    first_name=user.first_name
    last_name=user.last_name
    email=user.email
    ref_id=reference
    phone="+251"+username
    url = "https://api.chapa.co/v1/transaction/initialize"
    payload = {
    "amount": "10",
    "currency": "ETB",
    "email": f"{email}",
    "first_name": f"{first_name}",
    "last_name": f"{last_name}",
    
    "tx_ref": f"{ref_id}",
    "checkout_url":"https://api.chapa.co/v1/hosted/pay",
    "callback_url": "https://webhook.site/077164d6-29cb-40df-ba29-8a00e59a7e60",
    "return_url": "http://127.0.0.1:8000/users/payment",
    "customization": {
    "title": "Payment",
    "description": "I love online payments"
    }
    }
    headers = {
    'Authorization': 'Bearer CHASECK_TEST-Scrv8NSzaeXO28rVMifKJ6mAkv2CTVKo',
    'Content-Type': 'application/json'
    }
      
    response = requests.post(url, json=payload, headers=headers)
    data = response.json()
    print(data)
    return chapa_webhook(request)

def is_ajax(request):
    return  request.headers.get('X-Requested-With') == 'XMLHttpRequest'
@csrf_exempt  # Disable CSRF for this view
def webhook(request):
    if request.method == 'POST':
        update = json.loads(request.body)

        # Check if it's a start command or any message
        if 'message' in update:
            chat_id = update['message']['chat']['id']
            username = update['message']['chat'].get('username', 'Unknown')

            # Save chat_id to the database if it doesn't exist
            subscriber, created = Subscriber.objects.get_or_create(chat_id=chat_id)

            if created:
                # Send welcome message to new subscriber
                send_message(chat_id, "Welcome! You have been subscribed.")
                print(chat_id)
            else:
                send_message(chat_id, "You are already subscribed.")
                print(chat_id)

        return JsonResponse({'status': 'ok'})

    return JsonResponse({'status': 'error'}, status=400)
def send_message(chat_id, text):
    url = f'https://api.telegram.org/bot{BOT_TOKEN}/sendMessage'
    payload = {
        'chat_id': chat_id,
        'text': text
    }
    requests.post(url, json=payload)
@login_required
def create_cv(request):
    form=Education_form()
    user=User.objects.get(username=request.user)
    if request.method=="POST":
        cv=request.POST.get('cv_name',False)
        user_cv=User_cv(cv_name=cv,user=user)
        user_cv.save()
        user.cv=1
        user.save()
            
    form1=Expriance_form()
    form2=Skill_form()
    form3=Project_form()
    return render(request,"users/create_cv.html",{'form':form,'user':user,'expform':form1,'form2':form2,'form3':form3})
def applied_job(request,id):
    job=Blog.objects.get(id=id)
    user=User.objects.get(username=request.user)
    if request.method=="POST":
        try:
           #user_cv=User_cv.objects.get(user=user)
           aplied=Applid.objects.update_or_create(applide_by=user,job_applied=job)
         
           messages.success(request,"Successfully applied")
        except:
            return redirect('users:create_cv')
    if user.cv==0:
        return render(request,"users/applied.html",{'job':job})
    else:
       #user_cv=User_cv.objects.get(user=user)
       return render(request,"users/applied.html",{'job':job})
def my_application(request):
    user=User.objects.get(username=request.user)
    aplid=Applid.objects.filter(applide_by=user)
    
    return render(request,"users/my_application.html",{'applied':aplid})
def about_us(request):
    return render(request,"users/about_us.html")
def contact_us(request):
    if request.method=="POST":
        try:
            fname=request.POST.get('fname',False)
            descr=request.POST.get('descr',False)
            email=request.POST.get('email',False)
            contact=Contact(username=fname,message=descr,email=email)
            contact.save()
            messages.success(request,"Your request sent to admin")
        except:
            pass
        
        
    return render(request,"users/contact_us.html")
def getme(request):
    url=f"https://api.telegram.org/bot{BOT_TOKEN}/getUpdates"
    try:
        update = requests.get(url).json()
        user=User.objects.get(username=request.user)
        for msg in update['result']:
            chat_id=msg['message']['chat']['id']
            subscriber, created = Subscriber.objects.get_or_create(user=user)
            subscriber.chat_id=chat_id
            subscriber.save()

            if created:
               
                send_message(chat_id, "Welcome! You have been subscribed.")
                print(chat_id)
            else:
                send_message(chat_id, "You are already subscribed or You are trying to subscribe our bot by other account we only allow one.")
        
        
    except:
        pass
   
    return requests.get(url).json()
@csrf_exempt
def subscribe(request):
    getme(request)
    user=User.objects.get(username=request.user)
    if request.method=="POST":
        try:
            min_ex=request.POST.get('mx',False)
            max_ex=request.POST.get('mn',False)
            cats=request.POST.get('cat',False)
            salary=request.POST.get('salary',False)
            cata_gories=Catagories.objects.get(id=cats)
            sub=Subscribe(min_exp=min_ex,max_exp=max_ex,catagories=cata_gories,user=user,salary=salary)
            sub.save()
            messages.success(request,"Your request sent to admin")
        except:
            pass
    cat=Catagories.objects.all()
    subscrb=Subscribe.objects.filter(user=user)
    subs=""
    try:
       subsc=Subscriber.objects.get(user=user)
       subs=subsc.user
       
    except:
        pass
    
   
    return render(request,"users/subscribe.html",{'cat':cat,"sub":subscrb,'tsub':subs})
def withdraw(request,id):
    ap=Applid.objects.get(id=id)
    ap.delete()
    messages.success(request,f"You are Successfully withdraw your application for {ap.job_applied.title} ")
    return redirect("users:my_application")
def unsubscribe(request,id):
    ap=Subscribe.objects.get(id=id)
    ap.delete()
    messages.success(request,f"You are Successfully unsubscribe your subscription for {ap.catagories.name} You are no more get notication about this Catagories")
    return redirect("users:subscribe")
def payment(request):
    if request.method=="POST":
        form=Chapa_form(request.POST)
        if form.is_valid():
            form.save()
            
    form=Chapa_form()
    return render(request,"users/payment.html",{'form':form})
def list_job_by_catagory(request,id):
    cat=Catagories.objects.get(id=id)
    blog=Blog.objects.filter(catagory=cat)
    return render(request,"users/job_by_cat.html",{'blog':blog})
def advert_detail(request,id):
    adv=Post_advert.objects.get(id=id)
    return render(request,"users/advert_detail.html",{'adv':adv})

