from django.db import models
from datetime import datetime, timedelta
from django.db import models 
from ckeditor.fields import RichTextField
from django.contrib.auth.models import User
typ=models.IntegerField(default=0)
typ.contribute_to_class(User,"typ")
verfied=models.IntegerField(default=False)
verfied.contribute_to_class(User,"verfied")
phone=models.IntegerField(null=True)
phone.contribute_to_class(User,"phone")
uid=models.CharField(max_length=255,null=True)
uid.contribute_to_class(User,"uid")
cv=models.IntegerField(default=0,null=True)
cv.contribute_to_class(User,"cv")

# Create your models here.
class Catagories(models.Model):
    name=models.CharField(max_length=255,null=True)
    user=models.ForeignKey(User,on_delete=models.CASCADE,null=True)
    created_at=models.DateTimeField(auto_now=True,null=True)
    is_active=models.BooleanField(default=True,null=True)
    description=models.TextField(null=True)
    def __str__(self):
        return self.name

class Blog(models.Model):
    title=models.CharField(max_length=255,null=True)
    descr=models.TextField(null=True)
    text= RichTextField(blank=True,null=True)
    user=models.ForeignKey(User,on_delete=models.CASCADE,null=True)
    posted_at=models.DateTimeField(auto_now=True)
    dedline=models.DateTimeField(null=True)
    slug=models.SlugField(null=True)
    archived=models.BooleanField(default=False)
    catagory=models.ForeignKey(Catagories,on_delete=models.CASCADE,null=True)
    min_expriance=models.IntegerField(null=True)
    max_expriance=models.IntegerField(null=True)
    location=models.CharField(max_length=255,null=True)
    salary=models.CharField(max_length=255,null=True)
    def __str__(self):
        return self.title
class User_details(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE,null=True)
    have_org=models.BooleanField(default=False)
    org_name=models.CharField(max_length=255,null=True)
    catag=models.CharField(max_length=255,null=True)
    
class Departiment(models.Model):
    title=models.CharField(max_length=255,null=True)
    catagory=models.ForeignKey(Catagories,on_delete=models.CASCADE,null=True)
    decription=models.TextField(null=True)
    def __str__(self):
        return self.title


    
    

