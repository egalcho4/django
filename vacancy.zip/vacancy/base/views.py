from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.models import User
from .models import *
from django.contrib import messages
from django.core.paginator import Paginator
from django.http import JsonResponse
from organization.models import *
from datetime import datetime
from organization.forms import *
from users.models import *
import json
from django.core.serializers import serialize
from django.contrib.auth.decorators import login_required
from .forms import *
from django.views.decorators.csrf import csrf_exempt
import json
import requests
from vacancy import settings 
bot_token=settings.BOT_TOKEN
bot_url=settings.BOT_URL_UP
chat_id="5792653413"
from django.http import HttpResponse
# Create your views here.
def send_sms_to_channel(msg):
 chanell=f"https://api.telegram.org/bot{bot_token}/sendMessage?chat_id=@jobvacancypost&text={msg}"
 return requests.get(chanell)
def send_message(msg):
    return requests.get(f"https://api.telegram.org/bot{bot_token}/sendMessage?chat_id={chat_id}&text={msg}")


def login_users(request):
    if request.method=="POST":
        try:
            username=request.POST.get('username',False)
            password=request.POST.get('password',False)
            try:
                user=authenticate(username=username,password=password)
                if user is not None:
                    login(request,user)
                    if user.typ==1 and user.cv==2:
                        return redirect('org:home_pagetender_home')
                    elif user.typ==1 and user.cv==1:
                        return redirect('base:home_page')
                    else:
                        return redirect('base:home')
                   
            except:
                pass
        except:
            pass
    return render(request,"base/login.html")
def home(request):
    user=User.objects.get(username=request.user)
    chap=Chapa_Data.objects.all().order_by('-id')[:7]
    users=User.objects.all().order_by('-id')[:5]
    return render(request,"base/home.html",{'chapa':chap,"users":users})
def is_ajax(request):
    return  request.headers.get('X-Requested-With') == 'XMLHttpRequest'
def blog_post(request):
    form=Blog_form()
    if request.method=='POST':
        bl_form=Blog_form(request.POST)
        if bl_form.is_valid():
            bl_form.save()
            msg=bl_form.cleaned_data['title']
            mtourl=msg.replace(" ", "-")
            msg_to_send=msg+"\n visit here for more information"+mtourl+"visit mastawokia.net for more information"
            dscr=bl_form.cleaned_data['text']
            send_to_chn=msg_to_send+"\n"+dscr
            send_message(msg_to_send)
            send_sms_to_channel(send_to_chn)
        messages.success(request,"successfully published")
        return redirect('base:blog_post')
    cat=Catagories.objects.filter()
    return render(request,"base/post.html",{'cat':cat,"form":form})
def manage_post(request):
    user=User.objects.get(username=request.user)
    blog=Blog.objects.filter(user=user)
    paginator = Paginator(blog, 2)  # Show 25 contacts per page.

    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)
    
    return render(request,"base/manage_post.html",{"page_obj":page_obj})
def upadate_post(request,id):
    blog=Blog.objects.get(id=id)
    user=User.objects.get(username=request.user)
    form=Blog_form(instance=blog)
    if request.method=='POST':
        bl_form=Blog_form(request.POST,instance=blog)
        if bl_form.is_valid():
            bl_form.save()
            msg=bl_form.cleaned_data['title']
            mtourl=msg.replace(" ", "-")
            msg_to_send=msg+"\n updated visit here for more information"+mtourl+"visit mastawokia.net for more information"
            dscr=bl_form.cleaned_data['text']
            send_to_chn=msg_to_send+"\n"+dscr
            send_message(msg_to_send)
            send_sms_to_channel(send_to_chn)
            messages.success(request,"successfully updated")
        return redirect('base:update_post',id)
  
    cat=Catagories.objects.all()
    return render(request,"base/update_post.html",{'blog':blog,'cat':cat,'form':form})

def home_page(request):
   
    blog=Blog.objects.all().order_by('-id')
    paginator = Paginator(blog, 5)  # Show 25 contacts per page.

    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)
    cpage_objs=Catagories.objects.all().order_by('-id')
    cpaginator = Paginator( cpage_objs, 5)  # Show 25 contacts per page.

    
    cpage_obj = cpaginator.get_page(page_number)
    ch=Chereta.objects.all()
    #ch=json.dumps(chereta)
    #ch=serialize('json',chereta)
    if is_ajax(request=request):
        print(ch)
        return JsonResponse(request,{"ch":ch},status=200)
    user=[]
    verfied=0
    try:
        user=User.objects.get(username=request.user)
        verfied=user.verfied
    except:
        pass
    job=Blog.objects.all().order_by('-id')
    advert=Post_advert.objects.all().order_by('-id')[:10]
    return render(request,"base/home_page.html",{'adv':advert,'page_obj':page_obj,'cpage_obj':cpage_obj,'user':user,'ch':ch,'verfied':verfied,'job':job})
def manage_catagory(request):
    if is_ajax(request=request):
        title=request.POST.get('title',False)
        user=User.objects.get(username=request.user)
        cat=Catagories(name=title,user=user)
        cat.save()
        sub="submited successfully"
        return JsonResponse(request,{'submit':sub},status=200)
    
    cat=Catagories.objects.filter()
        
    return render(request,"base/manage_catagory.html",{'cat':cat})
def departiment(request):
    if is_ajax(request=request):
        title=request.POST.get('title',False)
        catag=request.POST.get('catag',False)
        descr=request.POST.get('descr',False)
        user=User.objects.get(username=request.user)
        cats=Catagories.objects.get(id=catag)
        cat=Departiment(title=title,decription=descr,catagory=cats)
        cat.save()
        sub="submited successfully"
        return JsonResponse(request,{'submit':sub},status=200)
    
    dep=Catagories.objects.filter()
    depart=Departiment.objects.filter()
    return render(request,"base/departiment.html",{'cat':dep,'dep':depart})
def more_about_catagory(request,id):
    return render(request,"base/more.html")
def new_chereta(request):
    
    if request.method=="POST":
        form=Chereta_form(request.POST)
        if form.is_valid():
            form.save()
            title=form.cleaned_data['title']
            ch=Chereta.objects.get(title=title)
            user=User.objects.get(username=request.user)
            ch.posted_by=user
            ch.save()
            print(title)
        
        messages.success(request,"successfully created")
    form=Chereta_form()
    cher=Chereta.objects.all()
    title_search=request.GET.get('title_search',False)
    if title_search !="" or title_search is not None:
        cher=Chereta.objects.filter(title__icontains=title_search)
    else:
         cher=cher
    return render(request,"base/new_chereta.html",{'form':form,'cher':cher})
def lists_of_tender(request):
    if request.method=="POST":
        title_search=request.POST.get('title_search',False)
        cher=Chereta.objects.filter(title__icontains=title_search)
        return render(request,"base/list_tender.html",{'cher':cher})
    cher=Chereta.objects.all()  
    return render(request,"base/list_tender.html",{'cher':cher})
def update_chereta(request,id):
    tender_obj=Chereta.objects.get(id=id)
    form=Chereta_form(instance=tender_obj)
    try:
        if request.method=="POST":
            form=Chereta_form(request.POST,instance=tender_obj)
            if form.is_valid():
                form.save()
                messages.success(request,"you are successfull update Tendar")
                return render(request,"base/update_chereta.html",{'form':form})
    except:
        pass
    return render(request,"base/update_chereta.html",{'form':form})
        
def verfie_account(request):
    if request.method=="POST":
        user=User.objects.get(username=request.user)
        user.verfied=True
        user.save()
        return redirect('base:home_page')
    return render(request,"users/verfied.html")
def user_logout(request):
    user=User.objects.get(username=request.user)
    if user is not None:
        logout(request)
        return redirect("base:home_page")
def subscribers(request):
    user=User.objects.get(username=request.user)
    sub=Subscribe.objects.all().order_by('-id')
    paginator = Paginator(sub, 5)  # Show 25 contacts per page.

    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)
    return render(request,"base/subscribers.html",{"page_obj":page_obj})
def payments(request):
    chapa=Chapa_Data.objects.filter().order_by('-id')
    paginator = Paginator(chapa, 5)  # Show 25 contacts per page.

    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)
    return render(request,"base/payments.html",{"page_obj":page_obj})
def post_advert(request):
    form=Advert_form()
    if request.method=="POST":
        form=Advert_form(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"adverted  successfully")
                           
    return render(request,"base/post_advert.html",{'form':form})
def advert(request):
    adv=Post_advert.objects.all().order_by('-id')
    paginator = Paginator(adv, 5)  # Show 25 contacts per page.

    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)
    return render(request,"base/advert.html",{'cpage_obj':page_obj})
def update_adv(request,id):
    adv=Post_advert.objects.get(id=id)
    form=Advert_form(instance=adv)
    if request.method=="POST":
        form=Advert_form(request.POST,instance=adv)
        if form.is_valid():
            form.save()
            messages.success(request,"adverted  successfully updated")
    return render(request,"base/update_advert.html",{"form":form})
def all_applications(request):
    jobs=Blog.objects.all().order_by('-id')
    paginator = Paginator(jobs, 5)  # Show 25 contacts per page.

    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)
    return render(request,"base/all_app.html",{"page_obj":page_obj})
def contact_message(request):
    cont=Contact.objects.all().order_by('-id')
    paginator = Paginator(cont, 5)  # Show 25 contacts per page.

    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)
    return render(request,"base/contact.html",{"page_obj":page_obj})
def message(request,id):
    cont=Contact.objects.get(id=id)
    if request.method=="POST":
        repy=request.POST.get('replay',False)
        cont.replay=repy
        cont.save()
    return render(request,"base/messge.html",{'cont':cont})