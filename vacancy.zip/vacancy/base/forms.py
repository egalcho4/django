from .models import *
from django.forms import ModelForm
class Blog_form(ModelForm):
    class Meta:
         model=Blog
         fields=['title','dedline','catagory','min_expriance','max_expriance','text','location','salary']