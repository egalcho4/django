from django.urls import path
from . import views
app_name="base"
urlpatterns = [
    path('login/',views.login_users,name="login"),
    path('home/',views.home,name="home"),
    path('blog_post/',views.blog_post,name="blog_post"),
    path('manage_post/',views.manage_post,name="manage_post"),
    path('update_post/<int:id>',views.upadate_post,name="update_post"),
    path('',views.home_page,name="home_page"),
    path('manage_catagory/',views.manage_catagory,name="manage_catagory"),
    path('depart/',views.departiment,name="departiment"),
    path('new_chereta/',views.new_chereta,name="new_chereta"),
    path('logout/',views.user_logout,name="logout"),
    path('subscribers/',views.subscribers,name="subscribers"),
    path('update_chereta/<int:id>',views.update_chereta,name="update_chereta"),
    path('list_tender/',views.lists_of_tender,name="list_tender"),
    path('payments/',views.payments,name="payments"),
    path('post_advert/',views.post_advert,name="post_advert"),
    path('advert/',views.advert,name="advert"),
    path('update_adv/<int:id>',views.update_adv,name="update_adv"),
    path('all_application/',views.all_applications,name="all_application"),
    path('contact/',views.contact_message,name="contact"),
    path('message/<int:id>',views.message,name="message"),
]
